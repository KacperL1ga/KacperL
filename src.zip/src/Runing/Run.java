package Runing;

public class Run {
    /*
    * w klasie input beda zdefiniowane metody
    * input string int double inne */
    Input input = new Input();
    public void runing() {
        int wybor;
        while (true){
            Menu(); // menu programu
            wybor = input.inputInt(); // metoda do wczytania int
            switch (wybor){
                case 1 ->viewCircle();
                //kolejen case
                case 8 ->Close();
                default -> defaultInstructioon();
            }//koniec switch
        }//koneic while
    }// koniec run

    private void defaultInstructioon() {
        System.out.println("Bledne dane, koniec programu");
        System.exit(0);
    }

    private void Close() {
        System.out.println("Czy na pewno chcesz wyjść? t || T");
        String znak = input.inputChar();
        String str1 = "t", str2 = "T";
        if (znak.equals(str1) || znak.equals(str2)) System.exit(0);
    }

    private void viewCircle() {
        //utworzenie obiektu danej klasy
        /*
        * podanie nazy figury
        * podanie niezbędnych wartości
        * sprwadzenie czy podano poprana wartosc if lub abs
        * wywolanie metody view()*/
        System.out.println("Kolo :) .. czekam na reszte kodu ");
    }

    private void Menu() {
        System.out.println("Kalkulator figur geometrycznyhc");
        System.out.println("1. Kolo\n"+
                "2. Kwadrat i inne \n"+
                "8. Wyjscie");
        System.out.println("\n\nWybierz opcje: ");
    }


}//koniec klasy
